

using System.Drawing;
namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            String imagePath = "C:\\Users\\lg\\Documents\\test\\bk.jpg";
            Image backgroundImage = Image.FromFile(imagePath);
            this.BackgroundImage = backgroundImage;

            Graphics g = Graphics.FromImage(backgroundImage);

            int centerX = 650; // �߽� X ��ǥ
            int centerY = 50; // �߽� Y ��ǥ
            int radius = 22; // ������
            int interval = 59;//�� ������ ���� 
            // ���� �׵θ� ���� ����
            Pen borderPen = new Pen(Color.GreenYellow, 10);

            // ���� ���� ���� ����
            Brush fillBrush = new SolidBrush(Color.Purple);

            // �� �׸���
            g.DrawEllipse(borderPen, centerX - radius, centerY - radius, radius * 2, radius * 2);
            g.FillEllipse(fillBrush, centerX - radius, centerY - radius, radius * 2, radius * 2);

            Font numberFont = new Font("Arial", 24, FontStyle.Bold);
            Brush numberBrush = new SolidBrush(Color.White);
            string numberText = "0";
            SizeF numberSize = g.MeasureString(numberText, numberFont);
            float numberX = centerX - numberSize.Width / 2;
            float numberY = centerY - numberSize.Height / 2;
            g.DrawString(numberText, numberFont, numberBrush, numberX, numberY);

            for (int i = 1; i < 11; i++)
            {
                MemoryGaugeDrawLeft(g, borderPen, fillBrush, numberFont, numberBrush,
                centerX, centerY, radius, i, interval);
            }
            for (int i = 1; i < 11; i++)
            {
                MemoryGaugeDrawRight(g, borderPen, fillBrush, numberFont, numberBrush,
                centerX, centerY, radius, i, interval);
            }
            //���� �޸� ������ ��ο�
            // ������ �޸� ������ ��ο� 
            // ����� ���ҽ� ����
            borderPen.Dispose();
            fillBrush.Dispose();
            numberFont.Dispose();
            numberBrush.Dispose();
        }

        //���� �޸𸮰����� �׸��� �Լ�
        public void MemoryGaugeDrawLeft(Graphics g, Pen borderPen, Brush fillBrush, Font numberFont, Brush numberBrush,
            int centerX, int centerY, int radius, int i_strNum, int i_interval)
        {
            g.DrawEllipse(borderPen, centerX - radius - i_interval * i_strNum, centerY - radius, radius * 2, radius * 2);
            g.FillEllipse(fillBrush, centerX - radius - i_interval * i_strNum, centerY - radius, radius * 2, radius * 2);

            string numberText = i_strNum.ToString();
            SizeF numberSize = g.MeasureString(numberText, numberFont);
            float numberX = centerX - numberSize.Width / 2;
            float numberY = centerY - numberSize.Height / 2;
            g.DrawString(numberText, numberFont, numberBrush, numberX - i_interval * i_strNum, numberY);

        }

        public void MemoryGaugeDrawRight(Graphics g, Pen borderPen, Brush fillBrush, Font numberFont, Brush numberBrush,
            int centerX, int centerY, int radius, int i_strNum, int i_interval)
        {
            g.DrawEllipse(borderPen, centerX - radius + i_interval * i_strNum, centerY - radius, radius * 2, radius * 2);
            g.FillEllipse(fillBrush, centerX - radius + i_interval * i_strNum, centerY - radius, radius * 2, radius * 2);

            string numberText = i_strNum.ToString();
            SizeF numberSize = g.MeasureString(numberText, numberFont);
            float numberX = centerX - numberSize.Width / 2;
            float numberY = centerY - numberSize.Height / 2;
            g.DrawString(numberText, numberFont, numberBrush, numberX + i_interval * i_strNum, numberY);

        }

        private void Form1_Load(object sender, EventArgs e)
        {



        }
    }
}